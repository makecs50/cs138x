var backdrop = document.querySelector('.backdrop');

console.dir(backdrop)